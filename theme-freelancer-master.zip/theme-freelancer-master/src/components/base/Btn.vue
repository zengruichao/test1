<template>
  <v-btn
    color="secondary"
    rounded
  >
    <slot />
  </v-btn>
</template>
